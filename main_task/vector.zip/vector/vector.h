#ifndef __VECTOR__
#define __VECTOR__

#include <stddef.h>

typedef struct {
    int *items;
    size_t capacity;
    size_t begin;
    size_t end;
} Vector;

/**
    Allocates memory for v->items
*/
int Vector__init(Vector *v);

/**
    Deallocates memory for v->items
*/
void Vector__final(Vector *v);

/**
    Gets the count of items of the vector added before and not removed
*/
int Vector__size(const Vector *v, size_t *sz);

/**
    Adds n to the end of the vector if the vector allows
*/
int Vector__push_back(Vector *v, int n);

/**
    Gets the i-th item of the vector if the item is exist
*/
int Vector__get(Vector *v, size_t i, int *n);


#endif
